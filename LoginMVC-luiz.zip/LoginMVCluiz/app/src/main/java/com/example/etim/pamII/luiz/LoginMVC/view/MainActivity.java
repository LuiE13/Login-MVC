
package com.example.etim.pamII.luiz.LoginMVC.view;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.etim.pamII.luiz.LoginMVC.R;
import com.example.etim.pamII.luiz.LoginMVC.controller.UsuarioController;
import com.example.etim.pamII.luiz.LoginMVC.model.Usuario;

public class MainActivity extends AppCompatActivity {
    Usuario usuario;
    UsuarioController usuarioController;
    EditText nomeInsert,senhaInsert,emailInsert;
    Button cadastrar, logar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        initComponents();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        logar.setOnClickListener(view->{
            if (validarCampos()){
                usuario = new Usuario();
                String nome = nomeInsert.getText().toString();
                String email = emailInsert.getText().toString();
                String senha = senhaInsert.getText().toString();

                usuario.setNome(nome);
                usuario.setEmail(email);
                usuario.setSenha(senha);

                usuarioController = new UsuarioController(this);

                boolean isCheckUser
            }
        });
    }
}